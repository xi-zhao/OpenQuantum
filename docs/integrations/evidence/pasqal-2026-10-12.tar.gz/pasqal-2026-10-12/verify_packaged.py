"""Run from repository root with its prepared Pulser interpreter, after plugin:build.

The packaged SDK locator is inspected separately; this uses the same locked
prepared interpreter without installing the plugin or contacting a service.
"""
import json
from pathlib import Path
import socket
import sys
from unittest.mock import patch

evidence = Path('.openquantum/pasqal-evidence')
location = json.loads((evidence / 'packaged-sdk.json').read_text())
skill = Path(location['project']).parent / 'pasqal-experiments'
sys.path.insert(0, str(skill / 'scripts'))
import experiment
import workflow as w

output = evidence / 'packaged'
output.mkdir()
sequence = skill / 'examples/rabi_sequence.py'
spec = skill / 'examples/rabi_spec.json'
commands = [
    ['validate-spec', '--spec', str(spec)],
    ['prepare', '--spec', str(spec), '--sequence', str(sequence), '--out', str(output / 'plan.json')],
    ['local-run', '--plan', str(output / 'plan.json'), '--out', str(output / 'raw.json')],
    ['analyze', '--raw', str(output / 'raw.json'), '--sequence', str(sequence), '--out', str(output / 'analysis.json')],
    ['plot', '--report', str(output / 'analysis.json'), '--out', str(output / 'plot.png')],
]
checks = {'networkUsed': False, 'pluginInstalled': False, 'scientificValidation': 'not_evaluated',
          'python': sys.executable, 'module': w.__file__, 'commands': [], 'researchExamples': []}
with patch.object(socket.socket, 'connect', side_effect=AssertionError('Real network forbidden')):
    for args in commands:
        sys.argv = ['experiment.py', *args]
        checks['commands'].append({'args': args, 'result': experiment.main()})
    for folder in (skill / 'upstream/examples').iterdir():
        if not folder.is_dir():
            continue
        device = 'MockDevice' if folder.name == 'literature_z2_reproduction' else 'AnalogDevice'
        plan = w.prepare(folder / (folder.name + '_spec.json'), folder / (folder.name + '_sequence.py'),
                         output / (folder.name + '-plan.json'), local_device=device)
        checks['researchExamples'].append({'name': folder.name, 'localStandIn': device,
                                           'points': len(plan['rows']), 'atoms': len(plan['rows'][0]['atom_ids']),
                                           'totalShots': plan['total_shots'], 'numericallySimulated': False})
    ring = skill / 'upstream/examples/literature_z2_reproduction'
    try:
        w.prepare(ring / 'literature_z2_reproduction_spec.json', ring / 'literature_z2_reproduction_sequence.py',
                  output / 'must-not-exist.json', local_device='AnalogDevice')
        raise AssertionError('56-atom ring unexpectedly fit the 38-um stand-in')
    except ValueError as error:
        checks['rejectedGeometry'] = str(error)
assert w.read(output / 'analysis.json')['complete']
assert not (output / 'must-not-exist.json').exists()
w.write(output / 'checks.json', checks, new=True)
print(json.dumps(checks, indent=2))
