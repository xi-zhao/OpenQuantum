Pasqal source integration evidence, 2026-10-12.

Logs and raw artifacts are preserved. Absolute source and temporary paths identify the original run; they need not exist to inspect JSON data. No cloud account was used. The Harness model is a local protocol fixture. Packaged scripts ran with the source worktree's prepared, identically locked Pulser interpreter; this is not a plugin installation test. The three research plans are sequence construction only, not many-body numerical simulation.
